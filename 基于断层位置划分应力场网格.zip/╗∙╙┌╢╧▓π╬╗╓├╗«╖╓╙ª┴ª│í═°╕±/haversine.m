function d = haversine(lat1, lon1, lat2, lon2)
% Haversine formula (all ASCII, no non-ASCII characters)
%   lat1, lon1: vectors or scalars for point(s) 1 in degrees
%   lat2, lon2: scalars for point 2 in degrees
R = 6371; % Earth radius (km)
phi1 = deg2rad(lat1);
phi2 = deg2rad(lat2);
dphi = deg2rad(lat2 - lat1);
dlambda = deg2rad(lon2 - lon1);
a = sin(dphi/2).^2 + cos(phi1).*cos(phi2).*sin(dlambda/2).^2;
c = 2 .* atan2( sqrt(a), sqrt(1 - a) );
d = R .* c;
end