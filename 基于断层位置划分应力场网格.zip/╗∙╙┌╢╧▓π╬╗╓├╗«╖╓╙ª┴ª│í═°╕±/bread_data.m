clear; close all; clc;

%% ——— 参数 ———
searchR_km      = 20;   % 检索半径（km）
minExportCount  = 20;   % 只有当某断层地震数 > 此阈值时，才导出 Excel

%% 1. 读取断层表（无表头），并指定列名
T_faults = readtable('duanceng.xlsx', 'ReadVariableNames', false);
T_faults.Properties.VariableNames = {'断层名称','断层编号','经度','纬度'};

%% 2. 读取震源机制表（无表头），并指定列名
T_events = readtable('focal_mechanism.txt', 'ReadVariableNames', false);
T_events.Properties.VariableNames = {'经度','纬度','走向','倾角','滑动角'};

%% 3. 初始化 Map，用来存放每个断层下的地震 table
faultDataMap = containers.Map('KeyType','char','ValueType','any');

%% 4. 获取唯一的断层“名称+编号”组合
T_faults.('组合键') = strcat(T_faults.("断层名称"), '_', string(T_faults.("断层编号")));
uniqueFaultKeys = unique(T_faults.('组合键'));

%% 5. 对每个唯一断层编号组合进行搜索匹配
for i = 1:numel(uniqueFaultKeys)
    key = uniqueFaultKeys{i};  % 例如 "Tangshan_001"
    parts = split(key, '_');
    name = parts{1};
    id   = parts{2};

    % 提取该条断层编号对应的所有点
    sel = strcmp(T_faults.("断层名称"), name) & strcmp(string(T_faults.("断层编号")), id);
    subF = T_faults(sel, :);

    % 初始化匹配结果
    matched = table([],[],[],[],[], ...
        'VariableNames', {'经度','纬度','走向','倾角','滑动角'});

    % 对该断层所有点进行半径搜索匹配
    for j = 1:height(subF)
        lat0 = subF.("纬度")(j);
        lon0 = subF.("经度")(j);
        d_km = haversine(T_events.("纬度"), T_events.("经度"), lat0, lon0);
        idx = d_km <= searchR_km;
        if any(idx)
            matched = [matched; T_events(idx, :)];
        end
    end

    % 去重处理
    if ~isempty(matched)
        matched = unique(matched, 'rows');
    end

    % 存入 Map，以“断层名_编号”为键
    faultDataMap(key) = matched;

    % 若记录数超出阈值，导出为 Excel
    n = height(matched);
    if n >= minExportCount
        safeName = regexprep([name '_' id], '[\\\/:*?"<>|]', '_');  % 确保文件名合法
        outFile = sprintf('%s_quakes.xlsx', safeName);
        writetable(matched, outFile, 'FileType', 'spreadsheet', 'WriteVariableNames', false);
        fprintf('导出文件：%s （共 %d 条记录，超过阈值 %d）\n', outFile, n, minExportCount);
    else
        fprintf('断层 “%s” 编号 %s 地震数 %d ≤ 阈值 %d，未导出文件。\n', name, id, n, minExportCount);
    end
end

%% 6. 将 Map 导出至 base 工作区
assignin('base', 'faultDataMap', faultDataMap);